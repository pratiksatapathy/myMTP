//Refer KVStoreHeader.h for declarations
#include "KVStoreImplRedis.cpp"
