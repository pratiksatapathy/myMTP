//Refer KVStoreHeader.h in interface for declarations
#include "KVStoreImplRamCloud.cpp"
